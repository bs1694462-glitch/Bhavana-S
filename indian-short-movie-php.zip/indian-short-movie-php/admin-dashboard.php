<?php 
require_once 'includes/data.php';
require_once 'includes/header.php'; 
?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-3xl font-black uppercase text-white">Platform Dashboard</h1>
            <p class="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Real-time overview of users and films</p>
        </div>
    </div>

    <div class="grid grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="bg-cinema-card p-6 rounded-3xl border border-white/5">
            <p class="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-2">Total Short Films</p>
            <p class="text-3xl font-black text-white"><?php echo count($films); ?></p>
        </div>
        <div class="bg-cinema-card p-6 rounded-3xl border border-white/5">
            <p class="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-2">Filmmakers</p>
            <p class="text-3xl font-black text-white"><?php echo count($creators); ?></p>
        </div>
        <div class="bg-cinema-card p-6 rounded-3xl border border-white/5">
            <p class="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-2">Pending Reports</p>
            <p class="text-3xl font-black text-rose-500">0</p>
        </div>
        <div class="bg-cinema-card p-6 rounded-3xl border border-white/5">
            <p class="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-2">Video Views</p>
            <p class="text-3xl font-black text-teal-500">45.8K</p>
        </div>
    </div>

    <div class="bg-cinema-card rounded-3xl border border-white/5 overflow-hidden">
        <div class="p-6 border-b border-white/5">
            <h3 class="font-bold text-white uppercase tracking-wider text-xs">Recent Submissions</h3>
        </div>
        <table class="w-full text-left text-xs">
            <thead class="bg-white/5 text-gray-500 uppercase font-black tracking-widest">
                <tr>
                    <th class="p-4">Film Title</th>
                    <th class="p-4">Language</th>
                    <th class="p-4">Status</th>
                    <th class="p-4">Action</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-white/5 text-gray-300">
                <?php foreach ($films as $film): ?>
                <tr>
                    <td class="p-4 font-bold text-white"><?php echo $film['title']; ?></td>
                    <td class="p-4"><?php echo $film['language']; ?></td>
                    <td class="p-4"><span class="bg-emerald-500/10 text-emerald-500 px-2 py-1 rounded text-[10px] font-black uppercase"><?php echo $film['status']; ?></span></td>
                    <td class="p-4"><button class="text-cinema-accent hover:underline">Review</button></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
