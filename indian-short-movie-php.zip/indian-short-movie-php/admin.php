<?php require_once 'includes/header.php'; ?>
<div class="min-h-[calc(100vh-80px)] flex items-center justify-center p-4">
    <div class="max-w-md w-full bg-cinema-card rounded-[2.5rem] p-10 border border-white/5 shadow-2xl">
        <div class="text-center space-y-4 mb-10">
            <div class="w-20 h-20 rounded-[2rem] bg-cinema-accent flex items-center justify-center text-white mx-auto shadow-2xl shadow-cinema-accent/20">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.040L3 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622l-.982-3.016z" />
                </svg>
            </div>
            <h2 class="text-3xl font-black uppercase tracking-tighter text-white">Admin Portal</h2>
            <p class="text-[10px] text-gray-500 uppercase tracking-widest font-black">System Administrator Access</p>
        </div>
        <form action="admin-dashboard.php" class="space-y-6">
            <div class="space-y-2">
                <label class="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Email</label>
                <input type="email" value="admin@example.com" class="w-full bg-cinema-surface border border-white/10 rounded-2xl px-5 py-4 text-sm text-white focus:outline-none focus:border-cinema-accent transition-all">
            </div>
            <div class="space-y-2">
                <label class="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Password</label>
                <input type="password" value="admin123" class="w-full bg-cinema-surface border border-white/10 rounded-2xl px-5 py-4 text-sm text-white focus:outline-none focus:border-cinema-accent transition-all">
            </div>
            <button type="submit" class="w-full bg-cinema-accent text-white font-black py-4.5 rounded-2xl transition-all shadow-xl shadow-cinema-accent/20 uppercase text-xs tracking-widest">Sign In to Dashboard</button>
        </form>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
