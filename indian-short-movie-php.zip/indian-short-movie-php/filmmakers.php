<?php 
require_once 'includes/data.php';
require_once 'includes/header.php'; 
?>
<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
    <div class="space-y-2">
        <h1 class="text-4xl font-black text-white uppercase tracking-tight">Filmmaker Directory</h1>
        <p class="text-gray-500 font-bold uppercase tracking-[0.2em] text-sm">Visionary storytellers behind the lens</p>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <?php foreach ($creators as $creator): ?>
        <div class="bg-cinema-card rounded-[2.5rem] border border-white/5 p-10 flex flex-col sm:flex-row items-center gap-10 hover:border-teal-500/30 transition-all">
            <div class="w-32 h-32 rounded-[2rem] overflow-hidden border-2 border-teal-500/30 shrink-0">
                <img src="<?php echo $creator['avatar']; ?>" class="w-full h-full object-cover">
            </div>
            <div class="space-y-4 text-center sm:text-left">
                <div>
                    <h3 class="text-2xl font-black text-white tracking-tight"><?php echo $creator['name']; ?></h3>
                    <p class="text-[10px] text-gray-500 uppercase font-black tracking-widest"><?php echo $creator['handle']; ?></p>
                </div>
                <p class="text-sm text-gray-400 leading-relaxed"><?php echo $creator['bio']; ?></p>
                <div class="flex gap-4 justify-center sm:justify-start">
                    <button class="bg-white/5 text-white px-6 py-2 rounded-xl text-[10px] font-black uppercase border border-white/5">Follow</button>
                    <button class="bg-teal-500/10 text-teal-500 px-6 py-2 rounded-xl text-[10px] font-black uppercase border border-teal-500/20">Portfolio</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</main>
<?php require_once 'includes/footer.php'; ?>
