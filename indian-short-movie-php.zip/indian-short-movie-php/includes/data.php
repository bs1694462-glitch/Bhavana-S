<?php
$films = [
    [
        'id' => 'film-1',
        'title' => 'The Midnight Chai',
        'localTitle' => 'ಮಧ್ಯರಾತ್ರಿಯ ಚಹಾ',
        'posterUrl' => 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80',
        'backdropUrl' => 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=1600&q=80',
        'language' => 'Kannada',
        'rating' => 4.9,
        'synopsis' => 'On a rainy night in Majestic Bengaluru, an elderly chai stall owner and an ambitious software architect share stories that bridge generations and cultures.',
        'director' => 'Raghavendra Rao',
        'releaseYear' => 2026,
        'duration' => '14 mins',
        'isFeatured' => true,
        'status' => 'published',
        'genre' => 'Drama',
        'viewsCount' => 12500,
        'likesCount' => 1200
    ],
    [
        'id' => 'film-2',
        'title' => 'Kaveri Calling',
        'localTitle' => 'ಕಾವೇರಿ ಕರೆ',
        'posterUrl' => 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80',
        'language' => 'Kannada',
        'rating' => 4.8,
        'director' => 'Chetan Gowda',
        'releaseYear' => 2026,
        'duration' => '18 mins',
        'status' => 'published',
        'genre' => 'Folklore',
        'viewsCount' => 8900,
        'likesCount' => 750
    ],
    [
        'id' => 'film-4',
        'title' => 'Malgudi Shadows',
        'localTitle' => 'ಮಾಲ್ಗುಡಿ ಛಾಯೆಗಳು',
        'posterUrl' => 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=800&q=80',
        'language' => 'Kannada',
        'rating' => 4.9,
        'director' => 'Preeti Hegde',
        'releaseYear' => 2026,
        'duration' => '22 mins',
        'status' => 'published',
        'genre' => 'Mystery',
        'viewsCount' => 11200,
        'likesCount' => 980
    ]
];

$creators = [
    [
        'id' => 'c-1',
        'name' => 'Harri Kumar',
        'handle' => '@harrikumar',
        'avatar' => 'assets/images/harri-formal.jpg',
        'bio' => 'National Award-winning director focusing on rural narratives and social realism in Kannada cinema.',
        'followersCount' => 12500,
        'followingCount' => 45
    ],
    [
        'id' => 'c-2',
        'name' => 'Aishwarya Raman',
        'handle' => '@ashraman',
        'avatar' => 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
        'bio' => 'Visual storyteller exploring the intersection of modern life and traditional values in Chennai.',
        'followersCount' => 8900,
        'followingCount' => 120
    ]
];
?>
