    <!-- Footer -->
    <footer class="bg-cinema-surface border-t border-cinema-border mt-20 pt-16 pb-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
                <div class="space-y-6">
                    <div class="flex items-center gap-2 font-black text-lg text-white">
                        <span>indian</span><span class="text-cinema-accent">short</span><span>movie</span>
                    </div>
                    <p class="text-gray-400 text-xs leading-relaxed">Dedicated platform celebrating independent storytelling, short cinema, and visionary filmmakers across all Indian languages.</p>
                </div>
                <div>
                    <h4 class="text-white font-bold uppercase tracking-wider text-xs mb-6">Discover</h4>
                    <ul class="text-gray-400 text-xs space-y-4">
                        <li><a href="discover.php" class="hover:text-white transition-colors">Trending Now</a></li>
                        <li><a href="discover.php" class="hover:text-white transition-colors">Top Rated</a></li>
                        <li><a href="discover.php" class="hover:text-white transition-colors">Kannada Films</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-white font-bold uppercase tracking-wider text-xs mb-6">Social</h4>
                    <div class="flex items-center gap-4">
                        <a href="https://www.facebook.com/profile.php?id=61594788760056" target="_blank" class="text-gray-400 hover:text-white transition-colors">Facebook</a>
                        <a href="https://www.instagram.com/indian.short.movie/" target="_blank" class="text-gray-400 hover:text-white transition-colors">Instagram</a>
                        <a href="https://www.youtube.com/@Indianshortmovie-i2" target="_blank" class="text-gray-400 hover:text-white transition-colors">YouTube</a>
                    </div>
                </div>
            </div>
            <div class="border-t border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between gap-6 text-[10px] text-gray-500 font-bold uppercase tracking-widest">
                <div>
                    <span>© 2026 Indian Short Films. All rights reserved.</span>
                    <span class="mx-2 opacity-20">|</span>
                    <span>Designed and developed by With love ❤️ <a href="https://webhostingbaba.com/" target="_blank" class="text-cinema-accent hover:underline">HOSTING BABA</a></span>
                </div>
                <div class="flex items-center gap-6">
                    <a href="tel:9945443044" class="hover:text-white transition-colors">9945443044</a>
                    <a href="https://wa.me/919945443044" class="hover:text-white transition-colors">WhatsApp</a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
