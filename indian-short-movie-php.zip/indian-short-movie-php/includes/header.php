<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indian Short Movie - India's Stories on Screen</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #07080b; color: white; }
        .glass-panel { background: rgba(13, 14, 18, 0.8); backdrop-filter: blur(12px); }
        .cinema-accent { color: #e50914; }
        .bg-cinema-accent { background-color: #e50914; }
        .bg-cinema-surface { background-color: #0d0e12; }
        .bg-cinema-card { background-color: #16171d; }
        .border-cinema-border { border-color: rgba(255, 255, 255, 0.1); }
    </style>
</head>
<body>
    <!-- Navbar -->
    <header class="sticky top-0 z-50 glass-panel border-b border-cinema-border">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-20">
                <div class="flex items-center gap-8">
                    <a href="index.php" class="flex flex-col items-start select-none">
                        <div class="flex items-center gap-2">
                            <span class="font-black text-lg tracking-tight">indian</span>
                            <div class="bg-gradient-to-br from-[#f84464] to-[#dc2626] px-2 py-0.5 rounded text-xs font-black uppercase -rotate-2">short</div>
                            <span class="font-black text-lg tracking-tight">movie</span>
                        </div>
                        <div class="flex items-center gap-1.5 mt-0.5 opacity-60">
                            <span class="h-px w-3 bg-[#e50914]"></span>
                            <span class="text-[8px] font-bold tracking-[0.2em] uppercase">India's Stories on Screen</span>
                        </div>
                    </a>
                    <nav class="hidden md:flex items-center gap-6">
                        <a href="index.php" class="text-sm font-bold text-white">Home</a>
                        <a href="discover.php" class="text-sm font-medium text-gray-400 hover:text-white transition-colors">Discover</a>
                        <a href="watchlist.php" class="text-sm font-medium text-gray-400 hover:text-white transition-colors">Watchlist</a>
                        <a href="filmmakers.php" class="text-sm font-medium text-gray-400 hover:text-white transition-colors">Filmmakers</a>
                        <a href="search.php" class="text-sm font-medium text-gray-400 hover:text-white transition-colors">Search</a>
                        <a href="admin.php" class="text-sm font-medium text-gray-400 hover:text-white transition-colors">Admin</a>
                        <a href="login.php" class="text-sm font-medium text-gray-400 hover:text-white transition-colors">Sign In</a>
                    </nav>
                </div>
                <div class="flex items-center gap-4">
                    <a href="submit-film.php" class="px-6 py-2.5 rounded-xl bg-cinema-accent hover:opacity-90 text-[10px] font-black uppercase tracking-widest text-white transition-all shadow-lg">Submit Film</a>
                </div>
            </div>
        </div>
    </header>
