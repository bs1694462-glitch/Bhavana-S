<?php 
require_once 'includes/data.php';
require_once 'includes/header.php'; 
?>

<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-20">
    <!-- Hero Spotlight -->
    <?php $featured = $films[0]; ?>
    <section class="relative rounded-3xl overflow-hidden border border-cinema-border h-[500px]">
        <img src="<?php echo $featured['backdropUrl']; ?>" class="absolute inset-0 w-full h-full object-cover">
        <div class="absolute inset-0 bg-gradient-to-t from-[#07080b] via-[#07080b]/60 to-transparent"></div>
        <div class="absolute bottom-0 left-0 p-12 max-w-3xl space-y-6">
            <div class="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest">
                <span class="bg-cinema-accent px-3 py-1 rounded-full">Featured</span>
                <span class="bg-white/10 px-3 py-1 rounded-lg backdrop-blur-md"><?php echo $featured['language']; ?></span>
            </div>
            <h1 class="text-5xl font-black tracking-tight leading-none text-white"><?php echo $featured['title']; ?></h1>
            <p class="text-gray-300 text-sm leading-relaxed line-clamp-3"><?php echo $featured['synopsis']; ?></p>
            <div class="flex gap-4">
                <button class="bg-cinema-accent px-8 py-4 rounded-2xl text-xs font-black uppercase tracking-widest shadow-2xl text-white">Watch Film</button>
                <button class="bg-white/10 px-8 py-4 rounded-2xl text-xs font-black uppercase tracking-widest border border-white/10 backdrop-blur-md text-white">Details</button>
            </div>
        </div>
    </section>

    <!-- Top Rated -->
    <section class="space-y-6">
        <h2 class="text-2xl font-black uppercase tracking-tight border-l-4 border-yellow-500 pl-4 text-white">Top Rated Cinema</h2>
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6">
            <?php foreach ($films as $film): ?>
            <div class="bg-cinema-card rounded-2xl overflow-hidden border border-cinema-border group cursor-pointer">
                <div class="aspect-[2/3] overflow-hidden relative">
                    <img src="<?php echo $film['posterUrl']; ?>" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
                    <div class="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[8px] font-black text-yellow-500 border border-white/10">★ <?php echo $film['rating']; ?></div>
                    <?php if ($film['language'] === 'Kannada'): ?>
                    <div class="absolute top-2 left-2 bg-cinema-accent px-2 py-1 rounded text-[8px] font-black uppercase text-white">Kannada</div>
                    <?php endif; ?>
                </div>
                <div class="p-4 space-y-1">
                    <h3 class="font-bold text-xs truncate text-white"><?php echo $film['title']; ?></h3>
                    <p class="text-[9px] text-gray-500 uppercase font-black tracking-tighter"><?php echo $film['director']; ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Visionary Filmmakers -->
    <section class="space-y-8">
        <h2 class="text-2xl font-black uppercase tracking-tight border-l-4 border-teal-500 pl-4 text-white">Visionary Filmmakers</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <?php foreach ($creators as $creator): ?>
            <div class="bg-cinema-card rounded-[2rem] border border-white/5 p-8 flex items-center gap-6">
                <div class="w-24 h-24 rounded-[1.5rem] overflow-hidden border-2 border-teal-500/30 shrink-0">
                    <img src="<?php echo $creator['avatar']; ?>" class="w-full h-full object-cover">
                </div>
                <div class="space-y-2">
                    <h3 class="text-xl font-black text-white"><?php echo $creator['name']; ?></h3>
                    <p class="text-[10px] text-gray-500 uppercase font-black tracking-widest"><?php echo $creator['handle']; ?></p>
                    <p class="text-xs text-gray-400 line-clamp-2"><?php echo $creator['bio']; ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
</main>

<?php require_once 'includes/footer.php'; ?>
