<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Film - Indian Short Movie</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f9fafb; color: #111827; }
        .cinema-accent { color: #f84464; }
        .bg-cinema-accent { background-color: #f84464; }
    </style>
</head>
<body class="py-12 px-4">
    <div class="max-w-4xl mx-auto bg-white rounded-[2.5rem] shadow-2xl border border-gray-200 overflow-hidden">
        <!-- Header -->
        <div class="px-10 py-8 border-b border-gray-100 flex items-center justify-between">
            <div class="flex items-center gap-4">
                <div class="w-14 h-14 rounded-2xl bg-pink-50 flex items-center justify-center text-[#f84464]">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                    </svg>
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <h2 class="text-2xl font-black uppercase tracking-tight">Submit Short Film / Movie</h2>
                        <span class="bg-amber-100 text-amber-700 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider">Curator Review</span>
                    </div>
                    <p class="text-gray-500 text-sm font-medium">Official submission gateway for filmmakers, creators, and production houses</p>
                </div>
            </div>
            <a href="index.php" class="text-gray-400 hover:text-gray-900 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </a>
        </div>

        <div class="p-10 bg-gray-50/50">
            <!-- Info Box -->
            <div class="mb-10 p-6 bg-blue-50 border border-blue-100 rounded-3xl flex gap-5">
                <div class="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-white shrink-0 shadow-lg shadow-blue-500/20">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.040L3 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622l-.982-3.016z" />
                    </svg>
                </div>
                <div>
                    <h4 class="text-blue-900 font-bold mb-1">Admin Approval Workflow:</h4>
                    <p class="text-blue-800 text-sm leading-relaxed">All submissions undergo review before public publication. Only approved films will appear on the OTT homepage and browsing catalogs.</p>
                </div>
            </div>

            <form action="submit.php" method="POST" enctype="multipart/form-data" class="space-y-10">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <!-- Left Column -->
                    <div class="space-y-8">
                        <div class="space-y-3">
                            <label class="text-xs font-black text-gray-500 uppercase tracking-widest ml-1">Film Title *</label>
                            <input type="text" name="title" required placeholder="e.g. Kaveri The Hidden Current" class="w-full bg-white border border-gray-200 rounded-2xl p-5 text-sm focus:outline-none focus:border-[#f84464] focus:ring-4 focus:pink-50 transition-all">
                        </div>
                        <div class="space-y-3">
                            <label class="text-xs font-black text-gray-500 uppercase tracking-widest ml-1">Format</label>
                            <select name="format" class="w-full bg-white border border-gray-200 rounded-2xl p-5 text-sm focus:outline-none focus:border-[#f84464] transition-all appearance-none">
                                <option>Short Film</option>
                                <option>Documentary</option>
                            </select>
                        </div>
                        <div class="space-y-3">
                            <label class="text-xs font-black text-gray-500 uppercase tracking-widest ml-1">Logline / Hook</label>
                            <textarea name="logline" placeholder="One-sentence hook..." class="w-full bg-white border border-gray-200 rounded-2xl p-5 text-sm focus:outline-none focus:border-[#f84464] transition-all min-h-[120px] resize-none"></textarea>
                        </div>
                    </div>
                    <!-- Right Column -->
                    <div class="space-y-8">
                        <div class="space-y-3">
                            <label class="text-xs font-black text-gray-500 uppercase tracking-widest ml-1">Master Video *</label>
                            <div class="relative border-2 border-dashed border-gray-200 rounded-2xl p-10 text-center bg-white hover:border-[#f84464] transition-colors cursor-pointer">
                                <input type="file" name="video" required class="absolute inset-0 opacity-0 cursor-pointer">
                                <p class="text-sm font-bold text-gray-900">Choose Video (MP4, MOV, WebM)</p>
                                <p class="text-[10px] text-gray-500 mt-2 uppercase font-black tracking-widest">Direct upload to local storage</p>
                            </div>
                        </div>
                        <div class="space-y-3">
                            <label class="text-xs font-black text-gray-500 uppercase tracking-widest ml-1">Promotional Poster</label>
                            <div class="relative border-2 border-dashed border-gray-200 rounded-2xl p-10 text-center bg-white hover:border-[#f84464] transition-colors cursor-pointer">
                                <input type="file" name="poster" class="absolute inset-0 opacity-0 cursor-pointer">
                                <p class="text-sm font-bold text-gray-900">Choose Poster (JPG, PNG)</p>
                                <p class="text-[10px] text-gray-500 mt-2 uppercase font-black tracking-widest">2:3 vertical recommended</p>
                            </div>
                        </div>
                    </div>
                </div>

                <button type="submit" class="w-full bg-[#f84464] hover:bg-[#d93454] text-white font-black py-6 rounded-3xl transition-all shadow-xl shadow-pink-100 uppercase text-xs tracking-[0.3em]">Initiate Submission</button>
            </form>
        </div>
    </div>
</body>
</html>
