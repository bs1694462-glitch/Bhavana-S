<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process form
    $title = $_POST['title'] ?? 'Untitled';
    // In a real app, move files and save to DB
    echo "<h1>Submission Successful!</h1>";
    echo "<p>Thank you for submitting <strong>" . htmlspecialchars($title) . "</strong>. Our curators will review it shortly.</p>";
    echo '<a href="index.php">Return to Home</a>';
} else {
    header('Location: submit-film.php');
}
?>
